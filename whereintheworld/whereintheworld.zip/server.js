// Express initialization
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var validator = require('validator');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/locations'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.post('/sendLocation', function (request, response) {
	response.header('Access-Control-Allow-Origin', '*');

	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;

	if (login == undefined || lat == undefined || lng == undefined) {
		response.send('POST request is in the wrong format.');
	} else {
		var timestamp = new Date();
		lat = parseFloat(lat);
		lng = parseFloat(lng);
		var toInsert = {
			'login': login,
			'lat': lat,
			'lng': lng,
			'created_at': timestamp
		}; 

		var locations = db.collection('locations', function(err, collection) {
			collection.insert(toInsert, function(err, doc) {
				if (err) {
					response.send('POST is in the wrong format!');
				} else {
					response.header('Content-Type', 'application/json');
					collection.find().toArray(function (err, cursor) {
						if(!err) {
							var students = '';
							for (var i = 100; i >= 0; i--) {
								if (cursor[i] != undefined) {
									students += JSON.stringify(cursor[i]);
									if (i != 0) { students +=',';}
								}
								
							}
							var resp = '{"characters":[], "students":[' + students + ']}';
							response.send(resp);
						} else {
							response.send(err);
						}

					});
				}
			});
		});
	}

});


app.get('/locations.json', function(request, response) {
	response.header('Content-Type', 'application/json');
	response.header('Access-Control-Allow-Origin', '*');
	var url = require('url');
	var url_parts = url.parse(request.url, true);
	var query = url_parts.query;
	var queryLogin = query.login;

	if (queryLogin == undefined) {
		response.send('Must give a login parameter!');
	} else {
		db.collection('locations', function(err, collection) {
			var page = '[';
			collection.find({login: queryLogin}).toArray(function(err, cursor) {
				if (!err) {
					for (var i = cursor.length - 1; i >= 0; i--) {
						page += JSON.stringify(cursor[i]);
						if (i != 0) { page += ',';}
					}
				} else {
					response.send(err);
				}
			page += ']';
			response.send(page);
			});
			
		});
		
	}
	

});

app.get('/', function (request, response) {
	response.header('Content-Type', 'text/html');
	response.header('Access-Control-Allow-Origin', '*');

	db.collection('locations', function (err, collection) {
		var indexPage = '';
		collection.find().toArray(function (err, students) {
			if (!err) {
				indexPage += '<!DOCTYPE HTML><html><head>';
				indexPage += '<meta charset="UTF-8"><title>Where are the Students?</title></head>';
				indexPage += '<body><h2>Where Have the Students Gone?</h2>';
				if (students.length == 0) {
					indexPage += 'No students have been spotted!';
				} else {
					indexPage += '<ul>';
					for (var i = students.length - 1; i >= 0; i--) {
						indexPage += '<li>' + students[i].login + ' was seen at ';
							indexPage += '(' + students[i].lat;
						indexPage += ', ' + students[i].lng +') ';
						indexPage += students[i].created_at + '.</li>';
					}
					indexPage += '</ul>';
				}
				indexPage += '</body></html>';
				response.send(indexPage);
			}
			else {
				response.send(err);
			}
		});
	});

});

app.get('/redline.json', function (request, response) {
	response.header('Content-Type', 'application/json');
	response.header('Access-Control-Allow-Origin', '*');
	
	var http = require('http');
	var options = {
		host: 'developer.mbta.com',
		port: 80,
		path: '/lib/rthr/red.json'
	};

	http.get(options, function(res) {
		var data = '';
		res.on('data', function(chunk) {
			data += chunk;
		});
		res.on('end', function() {
			response.send(data);
		});
	}).on('error', function(er) {
		console.log('Got error: ' + e.message);
	});
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);
